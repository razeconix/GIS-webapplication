var json__5 = {
"type": "FeatureCollection",
"name": "_5",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "NAME_T": "โรงพยาบาลรวมแพทย์พิษณุโลก", "NAME_E": "RUAM PHAET PHITSANULOK HOSPITAL", "X_UTM": 634242.7575, "Y_UTM": 1858939.2702 }, "geometry": { "type": "Point", "coordinates": [ 100.259818394048409, 16.809782370901882 ] } },
{ "type": "Feature", "properties": { "NAME_T": "โรงพยาบาลบางกระทุ่ม", "NAME_E": "BANG KRATHUM HOSPITAL", "X_UTM": 640571.7699, "Y_UTM": 1833045.5183000001 }, "geometry": { "type": "Point", "coordinates": [ 100.317597563345771, 16.575397507520925 ] } },
{ "type": "Feature", "properties": { "NAME_T": "โรงพยาบาลวัดโบสถ์", "NAME_E": "WAT BOT HOSPITAL", "X_UTM": 641289.3436, "Y_UTM": 1878773.5992000001 }, "geometry": { "type": "Point", "coordinates": [ 100.32718875527604, 16.98861356207399 ] } },
{ "type": "Feature", "properties": { "NAME_T": "โรงพยาบาลบางระกำ", "NAME_E": "BANG RAKAM HOSPITAL", "X_UTM": 619280.0935, "Y_UTM": 1853335.3214 }, "geometry": { "type": "Point", "coordinates": [ 100.119123384100178, 16.759945980718115 ] } },
{ "type": "Feature", "properties": { "NAME_T": "โรงพยาบาลกองบิน 46", "NAME_E": "WING 46 AIRFORCE HOSPITAL", "X_UTM": 635478.8811, "Y_UTM": 1856616.7338 }, "geometry": { "type": "Point", "coordinates": [ 100.271277118943928, 16.788721099955694 ] } },
{ "type": "Feature", "properties": { "NAME_T": "โรงพยาบาลพุทธชินราช", "NAME_E": "PHUTTHA CHINNARAT HOSPITAL", "X_UTM": 634725.5692, "Y_UTM": 1858661.6116 }, "geometry": { "type": "Point", "coordinates": [ 100.264331975486428, 16.807245229442593 ] } },
{ "type": "Feature", "properties": { "NAME_T": "โรงพยาบาลรังสีรักษา", "NAME_E": "RADIATION THERAPY HOSPITAL", "X_UTM": 635230.1911000001, "Y_UTM": 1860035.1235 }, "geometry": { "type": "Point", "coordinates": [ 100.269149344039889, 16.819629162087232 ] } },
{ "type": "Feature", "properties": { "NAME_T": "โรงพยาบาลรัตนเวช 2", "NAME_E": "RATTANA WET HOSPITAL 2", "X_UTM": 635666.8869, "Y_UTM": 1859697.4951 }, "geometry": { "type": "Point", "coordinates": [ 100.273226672561989, 16.816552516110683 ] } },
{ "type": "Feature", "properties": { "NAME_T": "โรงพยาบาลค่ายสมเด็จพระนเรศวรมหาราช", "NAME_E": "SOMDET PHRA NARESUAN MAHARAT CAMP HOSPITAL", "X_UTM": 633899.9418, "Y_UTM": 1861765.4241 }, "geometry": { "type": "Point", "coordinates": [ 100.2567701242384, 16.835343469116971 ] } },
{ "type": "Feature", "properties": { "NAME_T": "โรงพยาบาลเนินมะปราง", "NAME_E": "NOEN MAPRANG HOSPITAL", "X_UTM": 673313.3308, "Y_UTM": 1831778.2028000001 }, "geometry": { "type": "Point", "coordinates": [ 100.624311529205414, 16.561778254484341 ] } },
{ "type": "Feature", "properties": { "NAME_T": "โรงพยาบาลมหาวิทยาลัยนเรศวร", "NAME_E": "NARESUAN UNIVERSITY HOSPITAL", "X_UTM": 626757.057, "Y_UTM": 1852169.5448 }, "geometry": { "type": "Point", "coordinates": [ 100.189198523087228, 16.749017323023764 ] } },
{ "type": "Feature", "properties": { "NAME_T": "โรงพยาบาลตา-สายตา", "NAME_E": "SIGHT-OPTICAL HOSPITAL", "X_UTM": 635421.2035, "Y_UTM": 1860032.6411 }, "geometry": { "type": "Point", "coordinates": [ 100.2709415455694, 16.81959565318401 ] } },
{ "type": "Feature", "properties": { "NAME_T": "โรงพยาบาลรัตนเวชเด็ก", "NAME_E": "RATTANA WET PEDIATRIC HOSPITAL", "X_UTM": 635545.7475000001, "Y_UTM": 1859838.392 }, "geometry": { "type": "Point", "coordinates": [ 100.272098483014076, 16.817832904042039 ] } },
{ "type": "Feature", "properties": { "NAME_T": "โรงพยาบาลพิษณุเวช", "NAME_E": "PHITSANU WET HOSPITAL", "X_UTM": 634239.5738, "Y_UTM": 1858811.6432 }, "geometry": { "type": "Point", "coordinates": [ 100.259780905860097, 16.808629122349963 ] } },
{ "type": "Feature", "properties": { "NAME_T": "โรงพยาบาลสมเด็จพระยุพราชนครไทย", "NAME_E": "SOMDET PHRA YUPPHARAT NAKHON THAI HOSPITAL", "X_UTM": 694667.0455, "Y_UTM": 1890753.6933 }, "geometry": { "type": "Point", "coordinates": [ 100.829479938456117, 17.092970890155119 ] } },
{ "type": "Feature", "properties": { "NAME_T": "โรงพยาบาลชาติตระการ", "NAME_E": "CHAT TRAKAN HOSPITAL", "X_UTM": 670219.4568, "Y_UTM": 1910507.6923 }, "geometry": { "type": "Point", "coordinates": [ 100.601324469173306, 17.273408498691175 ] } },
{ "type": "Feature", "properties": { "NAME_T": "โรงพยาบาลพรหมพิราม", "NAME_E": "PHROM PHIRAM HOSPITAL", "X_UTM": 627794.8833, "Y_UTM": 1883793.9114000001 }, "geometry": { "type": "Point", "coordinates": [ 100.200740206197295, 17.034770975408694 ] } },
{ "type": "Feature", "properties": { "NAME_T": "โรงพยาบาลวังทอง", "NAME_E": "WANG THONG HOSPITAL", "X_UTM": 652871.6184, "Y_UTM": 1862331.7563 }, "geometry": { "type": "Point", "coordinates": [ 100.434836709781038, 16.839294808482368 ] } },
{ "type": "Feature", "properties": { "NAME_T": "โรงพยาบาลอินเตอร์เวชการ", "NAME_E": "INTER WETCHAKAN HOSPITAL", "X_UTM": 633787.7043, "Y_UTM": 1858451.9826 }, "geometry": { "type": "Point", "coordinates": [ 100.255519658961347, 16.805404602632937 ] } }
]
}
